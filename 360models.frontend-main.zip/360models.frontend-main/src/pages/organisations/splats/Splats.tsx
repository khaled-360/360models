export function Splats() {
    return null;
}
