dir=$(pwd)
cd ./dependencies/@360models.platform/types
npm run build
cd $dir